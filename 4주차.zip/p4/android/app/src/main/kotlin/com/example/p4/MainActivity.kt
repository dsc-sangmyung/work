package com.example.p4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
